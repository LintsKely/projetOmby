# cow-secure

## Message for Lints

Hi Linst, 
This is our project repository for the agronomy app, i called it "Cow-secure" (just a temporary name if you want).

 + In order to collaborate and do changes in the project, follow the instructions bellow.

## Instructions

### cloning the project

```bash
$ git clone [project git url]
```

### Installing dependencies

```bash
$ npm install
```

### List all branch

```bash
$ git branch
```

### Go to the secondary branch

```bash
$ git branch ckeckout secondary
```

### running the app

```bash
$ ionic serve
```

### And now do your change

## Let's do it !!

- Contact me - [Razafiarison Tafita](https://www.facebook.com/fragg.rzfrsn/)
