import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  public appPages = [
    { title: 'Cows', url: '/folder/Cows', icon: 'document-text' },
    { title: 'Events', url: '/folder/Events', icon: 'calendar' },
    { title: 'Charts', url: '/folder/Charts', icon: 'pie-chart' },
  ];
  public others = [
    { title: 'Settings', url: '/folder/Settings', icon: 'settings' },
    { title: 'Exit', url: '/folder/Exit', icon: 'exit' },
  ];
  constructor() {}
}
